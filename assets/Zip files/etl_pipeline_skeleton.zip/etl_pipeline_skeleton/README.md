# ETL Pipeline Skeleton

A modular extract-transform-load (ETL) scaffold you can reuse across projects.

## Structure
```
etl_pipeline_skeleton/
├─ data/
│  ├─ raw/        # drop inputs here
│  ├─ staging/    # optional normalization stage
│  └─ curated/    # outputs
├─ src/
│  ├─ extract.py
│  ├─ transform.py
│  ├─ load.py
│  └─ utils.py
├─ config/
│  └─ pipeline_config.json
├─ tests/
│  └─ test_transform.py
└─ main.py
```

## Quickstart
1. Place your source files in `data/raw/` and update paths in `config/pipeline_config.json`.
2. Create a virtual environment and install deps:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the pipeline:
   ```bash
   python main.py
   ```
4. Run tests:
   ```bash
   pytest -q
   ```

## Notes
- Parquet writes require `pyarrow` installed.
- Adjust `transforms.sales` in `pipeline_config.json` to your domain (filters, required columns, etc.).
