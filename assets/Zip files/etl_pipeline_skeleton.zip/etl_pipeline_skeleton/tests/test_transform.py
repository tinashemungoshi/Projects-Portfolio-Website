import pandas as pd
from src.transform import transform_domain

def test_transform_basic():
    df = pd.DataFrame({
        "period": ["2024-01", "2024-02", None],
        "stateid": ["CA", "NY", "TX"],
        "sectorname": ["residential", "industrial", "transportation"],
        "price": [10.0, 20.0, 30.0],
        "price-units": ["cents/kWh", "cents/kWh", "cents/kWh"],
    })

    cfg = {
        "period_col": "period",
        "dropna": ["price"],
        "filters": {"sectorname": ["residential", "transportation"]},
        "select": ["year", "month", "stateid", "price", "price-units"],
        "required_cols": ["period", "stateid", "sectorname", "price", "price-units"],
    }

    out = transform_domain(df, cfg)
    assert list(out.columns) == ["year", "month", "stateid", "price", "price-units"]
    assert len(out) == 2
    assert set(out["stateid"]) == {"CA", "TX"}
