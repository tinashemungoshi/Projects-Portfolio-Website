from __future__ import annotations
import json
from pathlib import Path
from src.extract import extract_tabular, extract_json
from src.transform import transform_domain
from src.load import load
from src.utils import get_logger, timed


def run(config_path: str = "config/pipeline_config.json") -> None:
    logger = get_logger()
    cfg = json.loads(Path(config_path).read_text(encoding="utf-8"))

    # Extract
    with timed(logger, "extract_sales"):
        sales_raw = extract_tabular(cfg["inputs"]["sales_tabular"])

    with timed(logger, "extract_capability"):
        capability_raw = extract_json(cfg["inputs"]["capability_json"])

    # Transform
    with timed(logger, "transform_sales"):
        sales_curated = transform_domain(sales_raw, cfg["transforms"]["sales"])

    # Load
    with timed(logger, "load_sales"):
        load(sales_curated, cfg["outputs"]["sales_curated"])

    with timed(logger, "load_capability"):
        # No domain transforms applied to capability in this template
        load(capability_raw, cfg["outputs"]["capability_flat"])

    logger.info("Pipeline completed successfully.")


if __name__ == "__main__":
    run()
