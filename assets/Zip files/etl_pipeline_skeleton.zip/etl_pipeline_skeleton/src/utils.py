import logging
from contextlib import contextmanager
from time import perf_counter


def get_logger(name: str = "pipeline") -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
        handler.setFormatter(fmt)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger


@contextmanager
def timed(logger: logging.Logger, label: str):
    start = perf_counter()
    logger.info(f"START: {label}")
    try:
        yield
    finally:
        dur = perf_counter() - start
        logger.info(f"END:   {label} (%.2fs)" % dur)
