from __future__ import annotations
import pandas as pd


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [c.strip().lower().replace(" ", "_") for c in df.columns]
    return df


def derive_calendar(df: pd.DataFrame, col: str = "period") -> pd.DataFrame:
    df = df.copy()
    if col in df.columns:
        s = df[col].astype(str)
        # naive split assuming formats like YYYY-MM or YYYY-MM-DD or YYYY/MM
        df["year"] = s.str.slice(0, 4)
        df["month"] = s.str.slice(5, 7)
    return df


def apply_filters(df: pd.DataFrame, filters: dict[str, list]) -> pd.DataFrame:
    df = df.copy()
    for col, allowed in filters.items():
        if col in df.columns:
            df = df[df[col].isin(allowed)]
    return df


def validate_schema(df: pd.DataFrame, required_cols: list[str]) -> None:
    missing = set(required_cols) - set(df.columns)
    if missing:
        raise AssertionError(f"Missing required columns: {sorted(missing)}")


def transform_domain(df: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    """Generic transform based on a small config contract."""
    df = normalize_columns(df)
    period_col = cfg.get("period_col", "period")
    df = derive_calendar(df, period_col)

    if "required_cols" in cfg:
        validate_schema(df, cfg["required_cols"])

    if "dropna" in cfg:
        df = df.dropna(subset=cfg["dropna"])

    if "filters" in cfg:
        df = apply_filters(df, cfg["filters"])

    if "select" in cfg:
        # only keep selected columns that actually exist
        select = [c for c in cfg["select"] if c in df.columns]
        df = df[select]

    return df
