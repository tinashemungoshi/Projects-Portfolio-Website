import pathlib
import pandas as pd


def load(df: pd.DataFrame, dest: str) -> None:
    """Write DataFrame to CSV or Parquet based on extension."""
    ext = pathlib.Path(dest).suffix.lower()
    pathlib.Path(dest).parent.mkdir(parents=True, exist_ok=True)
    if ext == ".csv":
        df.to_csv(dest, index=False)
    elif ext == ".parquet":
        df.to_parquet(dest, index=False)
    else:
        raise ValueError(f"Unsupported output format: {ext}")
