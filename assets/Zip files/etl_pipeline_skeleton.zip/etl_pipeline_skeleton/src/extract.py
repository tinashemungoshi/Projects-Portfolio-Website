import json
import pathlib
import pandas as pd


ALLOWED_TABULAR = {".csv", ".parquet"}


def extract_tabular(path: str) -> pd.DataFrame:
    """Read CSV or Parquet into a DataFrame with basic validation."""
    ext = pathlib.Path(path).suffix.lower()
    if ext not in ALLOWED_TABULAR:
        raise ValueError(f"Unsupported tabular format: {ext}")
    if ext == ".csv":
        return pd.read_csv(path)
    return pd.read_parquet(path)  # .parquet


def extract_json(path: str) -> pd.DataFrame:
    """Read JSON and flatten nested structures into columns."""
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return pd.json_normalize(data)
